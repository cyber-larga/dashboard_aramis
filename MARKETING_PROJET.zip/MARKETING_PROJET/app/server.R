library(shiny)
library(bslib)
library(bsicons)
library(dplyr)
library(ggplot2)
library(DT)
library(plotly)
library(FactoMineR)

# ==============================================================================
# Préparation des données
# ==============================================================================
df_clean <- read.csv("data/df_clean.csv", stringsAsFactors = FALSE)

df_clean <- df_clean %>%
  rename(
    brand = VEHICULE_MARQUE,
    model = VEHICULE_MODELE,
    buyer_year_birth = YEAR_NAISSANCE,
    price = PRIX_VENTE_TTC_COM,
    mileage = VEHICULE_KM,
    agency_dist = NEAREST_AGENCY_DISTANCE,
    delivery_type = TYPE_LIVRAISON_COM,
    engine_type = VEHICULE_ENERGIE,
    category = VEHICULE_CATEGORIE,
    equipments = OFFER_EQUIPMENTS_MAIN_LIST
  )

# Nettoyage et création des variables
current_year <- as.numeric(format(Sys.Date(), "%Y"))
df_clean$buyer_age <- current_year - df_clean$buyer_year_birth

# Variable : nombre d'équipements
# La colonne OFFER_EQUIPMENTS_MAIN_LIST contient des descriptions séparées par des virgules ou points-virgules
df_clean$nb_equipments <- sapply(strsplit(as.character(df_clean$equipments), ","), length)
# Gestion des valeurs vides
df_clean$nb_equipments[is.na(df_clean$equipments) | df_clean$equipments == ""] <- 0

# Extraction d'une liste fixe des équipements les plus premium/fréquents
top_equipments <- c(
  "Bluetooth", "GPS", "Caméra de recul", "Climatisation", "Régulateur de vitesse",
  "Radar de recul", "Jantes alliage", "Toit ouvrant"
)

for (eq in top_equipments) {
  col_name <- paste0("eq_", gsub("[-/ ]", "_", eq))
  df_clean[[col_name]] <- as.numeric(grepl(eq, df_clean$equipments, ignore.case = TRUE))
}

# Fusion de Apple Car Play et Android Auto (colinéarité)
df_clean$eq_Smartphone_Integration <- as.numeric(
  grepl("Apple Car Play", df_clean$equipments, ignore.case = TRUE) |
    grepl("Android Auto", df_clean$equipments, ignore.case = TRUE)
)

# Filtrage des valeurs aberrantes (ex: âge > 100 ou < 18)
df_clean <- df_clean %>%
  filter(buyer_age >= 18 & buyer_age <= 100)

df_clean$agency_dist <- as.numeric(df_clean$agency_dist)

# ==============================================================================
# Palette de couleurs sobre - design minimaliste et orienté "business"
# ==============================================================================
base_color <- "#2c3e50" # Bleu nuit (couleur principale neutre)
secondary_color <- "#18bc9c" # Vert (utilisé quand on compare ou met en évidence)
neutral_light <- "#ecf0f1" # Gris clair

server <- function(input, output, session) {
  df <- reactive({
    df_clean
  })

  # ----------------------------------------------------------------------------
  # KPI PAGE 1 : Affichage formaté
  # ----------------------------------------------------------------------------
  output$kpi_total <- renderText({
    format(nrow(df()), big.mark = " ")
  })
  output$kpi_prix <- renderText({
    paste0(format(round(mean(df()$price, na.rm = TRUE), 0), big.mark = " ", scientific = FALSE), " €")
  })
  output$kpi_km <- renderText({
    paste0(format(round(mean(df()$mileage, na.rm = TRUE), 0), big.mark = " ", scientific = FALSE), " km")
  })
  output$kpi_age <- renderText({
    paste0(round(mean(df()$buyer_age, na.rm = TRUE), 1), " ans")
  })
  output$kpi_distance <- renderText({
    paste0(format(round(mean(df()$agency_dist, na.rm = TRUE), 0), big.mark = " ", scientific = FALSE), " km")
  })

  # --- Détails des KPIs (Graphes miniatures) ---
  output$plot_detail_total <- renderPlotly({
    p <- df() %>%
      count(category) %>%
      mutate(custom_tooltip = paste0("<b>Catégorie :</b> ", category, "<br><b>Volume :</b> ", n)) %>%
      ggplot(aes(x = reorder(category, n), y = n, text = custom_tooltip)) +
      geom_col(fill = base_color) +
      coord_flip() +
      labs(x = NULL, y = NULL) +
      theme_minimal()
    ggplotly(p, tooltip = "text") %>% layout(margin = list(l = 0, r = 0, b = 0, t = 0)) %>% config(displayModeBar = FALSE)
  })

  output$plot_detail_prix <- renderPlotly({
    p <- ggplot(df(), aes(x = price)) +
      geom_density(fill = secondary_color, alpha = 0.5) +
      labs(x = NULL, y = NULL) +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Prix :</b> %{x:.0f} €<br><b>Densité :</b> %{y:.5f}<extra></extra>") %>%
      layout(margin = list(l = 0, r = 0, b = 0, t = 0)) %>% config(displayModeBar = FALSE)
  })

  output$plot_detail_km <- renderPlotly({
    p <- ggplot(df(), aes(x = mileage)) +
      geom_density(fill = base_color, alpha = 0.5) +
      labs(x = NULL, y = NULL) +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Kilométrage :</b> %{x:.0f} km<br><b>Densité :</b> %{y:.5f}<extra></extra>") %>%
      layout(margin = list(l = 0, r = 0, b = 0, t = 0)) %>% config(displayModeBar = FALSE)
  })

  output$plot_detail_age <- renderPlotly({
    p <- ggplot(df(), aes(x = buyer_age)) +
      geom_density(fill = secondary_color, alpha = 0.5) +
      labs(x = NULL, y = NULL) +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Âge :</b> %{x:.0f} ans<br><b>Densité :</b> %{y:.5f}<extra></extra>") %>%
      layout(margin = list(l = 0, r = 0, b = 0, t = 0)) %>% config(displayModeBar = FALSE)
  })

  output$plot_detail_distance <- renderPlotly({
    p <- ggplot(df(), aes(x = agency_dist)) +
      geom_density(fill = base_color, alpha = 0.5) +
      labs(x = NULL, y = NULL) +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Distance :</b> %{x:.0f} km<br><b>Densité :</b> %{y:.5f}<extra></extra>") %>%
      layout(margin = list(l = 0, r = 0, b = 0, t = 0)) %>% config(displayModeBar = FALSE)
  })

  # ----------------------------------------------------------------------------
  # GRAPHIQUES PAGE 1
  # ----------------------------------------------------------------------------
  output$hist_price <- renderPlotly({
    p <- ggplot(df(), aes(x = price)) +
      geom_histogram(fill = base_color, color = "white", bins = 30) +
      labs(x = "Prix (€)", y = "Volume") +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Prix central :</b> %{x:.0f} €<br><b>Volume :</b> %{y}<extra></extra>") %>%
      config(displayModeBar = FALSE)
  })

  output$hist_km <- renderPlotly({
    p <- ggplot(df(), aes(x = mileage)) +
      geom_histogram(fill = base_color, color = "white", bins = 30) +
      labs(x = "Kilométrage", y = "Volume") +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Kilométrage central :</b> %{x:.0f} km<br><b>Volume :</b> %{y}<extra></extra>") %>%
      config(displayModeBar = FALSE)
  })

  output$hist_delai <- renderPlotly({
    p <- ggplot(df(), aes(x = buyer_age)) +
      geom_histogram(fill = base_color, color = "white", bins = 30) +
      labs(x = "Âge de l'acheteur", y = "Volume") +
      theme_minimal()
    ggplotly(p) %>% 
      style(hovertemplate = "<b>Âge central :</b> %{x:.0f} ans<br><b>Volume :</b> %{y}<extra></extra>") %>%
      config(displayModeBar = FALSE)
  })

  output$bar_brand <- renderPlotly({
    dt_brand <- df() %>%
      count(brand) %>%
      arrange(desc(n)) %>%
      head(10) %>% # Top 10
      mutate(custom_tooltip = paste0("<b>Marque :</b> ", brand, "<br><b>Volume :</b> ", format(n, big.mark = " ", scientific = FALSE)))

    p <- ggplot(dt_brand, aes(x = reorder(brand, -n), y = n, text = custom_tooltip)) +
      geom_col(fill = base_color, width = 0.6) +
      labs(x = "Marque", y = "Volume") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
    ggplotly(p, tooltip = "text") %>% config(displayModeBar = FALSE)
  })

  output$table_global <- DT::renderDataTable({
    # Traduction et enrichissement des colonnes
    dt_show <- df() %>%
      mutate(Smartphone = ifelse(eq_Smartphone_Integration, "Oui", "Non")) %>%
      select(
        Marque = brand,
        Modèle = model,
        Catégorie = category,
        Énergie = engine_type,
        Prix = price,
        Kilométrage = mileage,
        `Nb Options` = nb_equipments,
        Smartphone,
        `Âge Acheteur` = buyer_age,
        `Dist. Agence (km)` = agency_dist
      )

    datatable(dt_show,
      filter = "top",
      options = list(
        pageLength = 10,
        lengthMenu = c(10, 50, 100),
        language = list(url = "//cdn.datatables.net/plug-ins/1.10.11/i18n/French.json")
      ),
      rownames = FALSE
    ) %>%
      formatCurrency("Prix", currency = "€", before = FALSE, digits = 0)
  })


  # ----------------------------------------------------------------------------
  # PAGE 2 : PROFIL ACHETEUR
  # ----------------------------------------------------------------------------

  df_h2 <- reactive({
    data <- df()

    if (!is.null(input$h2_category) && input$h2_category != "Toutes") {
      data <- data %>% filter(category == input$h2_category)
    }
    if (!is.null(input$h2_engine) && input$h2_engine != "Toutes") {
      if (input$h2_engine == "Thermique") {
        data <- data %>% filter(grepl("essence|diesel", tolower(engine_type)))
      } else if (input$h2_engine == "Hybride") {
        data <- data %>% filter(grepl("hybride", tolower(engine_type)))
      } else if (input$h2_engine == "Électrique") data <- data %>% filter(grepl("electrique|électrique", tolower(engine_type)))
    }
    data
  })

  output$h2_boxplot <- renderPlotly({
    data <- df_h2()
    req(nrow(data) > 0)

    # Sélection des 6 marques principales
    top_brands <- data %>%
      count(brand) %>%
      top_n(6, n) %>%
      pull(brand)
    df_plot <- data %>% filter(brand %in% top_brands)

    p <- ggplot(df_plot, aes(x = reorder(brand, buyer_age, FUN = median), y = buyer_age)) +
      geom_boxplot(fill = base_color, alpha = 0.8, color = "#1a252f", outlier.shape = NA) +
      labs(x = "Marque", y = "Âge de l'acheteur") +
      theme_minimal()
    suppressWarnings(ggplotly(p))
  })

  output$h2_scatter <- renderPlotly({
    data <- df_h2() %>%
      rename(`Âge de l'acheteur` = buyer_age, `Prix du véhicule` = price)
    req(nrow(data) > 0)
    p <- ggplot(data, aes(x = `Âge de l'acheteur`, y = `Prix du véhicule`)) +
      geom_point(alpha = 0.3, color = secondary_color) +
      geom_smooth(method = "lm", color = base_color, se = FALSE, linewidth = 1) +
      labs(x = "Âge de l'acheteur", y = "Prix du véhicule (€)") +
      theme_minimal()
    suppressWarnings(ggplotly(p))
  })

  output$h2_bar_age <- renderPlotly({
    data <- df_h2() %>% filter(!is.na(buyer_age), !is.na(category), category != "")
    req(nrow(data) > 0)

    d_age <- data %>%
      mutate(age_group = case_when(
        buyer_age <= 30 ~ "18-30 ans",
        buyer_age <= 45 ~ "31-45 ans",
        buyer_age <= 60 ~ "46-60 ans",
        TRUE ~ "61+ ans"
      )) %>%
      mutate(age_group = factor(age_group, levels = c("18-30 ans", "31-45 ans", "46-60 ans", "61+ ans"))) %>%
      count(age_group, category) %>%
      group_by(age_group) %>%
      mutate(proportion = n / sum(n)) %>%
      ungroup()

    p <- ggplot(d_age, aes(
      x = age_group, y = proportion, fill = category,
      text = paste0("<b>Tranche : </b>", age_group, "<br><b>Catégorie : </b>", category, "<br><b>Ventes : </b>", n, "<br><b>Part : </b>", round(proportion * 100, 1), " %")
    )) +
      geom_col(position = "fill", alpha = 0.9) +
      scale_y_continuous(labels = scales::percent) +
      scale_fill_brewer(palette = "Set2") +
      labs(x = "Tranche d'âge", y = "Proportion des ventes", fill = "Catégorie") +
      theme_minimal()

    suppressWarnings(ggplotly(p, tooltip = "text"))
  })

  output$h2_interpretation <- renderUI({
    data <- df_h2()
    if (nrow(data) < 10) {
      return(HTML("<b>Pas assez de données pour l'analyse statistique sur ce filtre.</b>"))
    }

    modele <- lm(price ~ buyer_age, data = data)
    pval <- summary(modele)$coefficients[2, 4]
    correlation <- cor(data$buyer_age, data$price, use = "complete.obs")

    texte <- if (is.na(pval)) {
      "Modèle incalculable avec les filtres sélectionnés."
    } else if (pval < 0.05) {
      if (correlation > 0) {
        "Statistiquement parlant, <strong>le budget de l'acheteur augmente significativement avec son âge</strong>. Les profils plus âgés acquièrent en moyenne des véhicules plus onéreux, confirmant un pouvoir d'achat supérieur."
      } else {
        "La tendance est inversée : sur ce segment, <strong>les acheteurs plus jeunes dépensent davantage</strong> pour leurs véhicules que les profils plus âgés."
      }
    } else {
      "La comparaison montre qu'<strong>il n'y a pas de corrélation forte entre le prix d'achat et l'âge de l'acheteur</strong>. Le budget voiture semble donc bien réparti indépendamment des tranches d'âge sur cette sélection."
    }

    tags$div(
      class = "alert alert-primary", style = "background-color: #e6f2f8; border-color: #003c58; color: #003c58;",
      tags$h5(tags$b("1. Conclusion Statistique sur le Pouvoir d'Achat")),
      HTML(texte),
      tags$hr(style = "border-top: 1px solid #003c58; opacity: 0.3; margin-top: 15px; margin-bottom: 15px;"),
      tags$h5(tags$b("2. Orientations pour le Marketing et les Vendeurs")),
      HTML("Ces informations permettent d'adapter concrètement la <strong>stratégie d'acquisition</strong> chez AramisAuto :
           <ul style='margin-bottom: 0px;'>
             <li><strong>Ciblage Publicitaire :</strong> Les véhicules haut de gamme devraient être poussés vers les tranches d'âge supérieures (31-60+). À l'inverse, l'entrée de gamme cible statistiquement les 18-30.</li>
             <li><strong>Approche en Agence :</strong> Les commerciaux peuvent anticiper le panier moyen d'un client potentiel en croisant son âge approximatif et la catégorie du véhicule regardée.</li>
           </ul>")
    )
  })


  # ----------------------------------------------------------------------------
  # PAGE 3 : TYPE DE MOTEUR ET BUDGET
  # ----------------------------------------------------------------------------
  # Couleurs du thème
  base_color <- "#003c58" # Bleu primaire
  secondary_color <- "#69d625" # Vert secondaire

  # 1. Préparation des données (regroupement propre des énergies)
  df_energie <- reactive({
    df_clean %>%
      # On utilise la nouvelle colonne 'engine_type'
      mutate(Type_Motorisation = case_when(
        grepl("essence|diesel", tolower(engine_type)) ~ "Thermique",
        grepl("hybride", tolower(engine_type)) ~ "Hybride",
        grepl("electrique|électrique", tolower(engine_type)) ~ "Électrique",
        TRUE ~ "Autre"
      )) %>%
      # On filtre sur la nouvelle colonne 'price'
      filter(Type_Motorisation != "Autre", !is.na(price))
  })

  # 2. Graphique Boxplot
  output$h4_boxplot <- renderPlotly({
    d_eng <- df_energie()

    p <- ggplot(d_eng, aes(x = reorder(Type_Motorisation, price, FUN = median), y = price)) +
      geom_boxplot(fill = base_color, alpha = 0.8) +
      labs(x = "Motorisation", y = "Prix du véhicule TTC (€)") +
      theme_minimal()

    suppressWarnings(ggplotly(p))
  })

  # 3. Graphique en barres (Volume)
  output$h4_bar <- renderPlotly({
    # Préparation des données
    d_eng <- df_energie() %>%
      count(Type_Motorisation) %>%
      mutate(label_tooltip = paste0(
        "<b>Motorisation :</b> ", Type_Motorisation,
        "<br><b>Ventes :</b> ", format(n, big.mark = " ")
      ))

    p <- ggplot(d_eng, aes(
      x = reorder(Type_Motorisation, -n),
      y = n,
      text = label_tooltip
    )) +
      geom_col(fill = secondary_color, width = 0.6) +
      labs(x = "Motorisation", y = "Volume de ventes") +
      theme_minimal()

    # Conversion en plotly en spécifiant d'utiliser uniquement l'argument "text"
    ggplotly(p, tooltip = "text") %>%
      config(displayModeBar = FALSE) # Optionnel : épure l'interface
  })


  # 4. Interprétation statistique globale (ANOVA + Catégories + Décote)
  output$h4_interpretation <- renderUI({
    d_eng <- df_energie()

    # Calcul ANOVA pour la première partie du texte
    if (length(unique(d_eng$Type_Motorisation)) > 1) {
      anova_res <- aov(price ~ Type_Motorisation, data = d_eng)
      pval <- summary(anova_res)[[1]][["Pr(>F)"]][1]
    } else {
      pval <- 1
    }

    # TEXTE 1 : Le Constat (Prix)
    texte_prix <- if (!is.na(pval) && pval < 0.05) {
      "<strong>Les véhicules Hybrides s'échangent à des prix supérieurs</strong> face au thermique (Essence, Diesel). Le marché valorise financièrement l'hybridation sur cette sélection."
    } else {
      "<strong>Il n'y a pas d'effet de premium lié au type d'énergie</strong>. Qu'il s'agisse d'un moteur Diesel, Essence ou Électrique, la distribution des prix payés est similaire."
    }

    # TEXTE 2 : L'effet Catégorie (Idée 1)
    texte_categorie <- "Le surcoût notable de l'hybride s'explique structurellement par notre catalogue : la technologie hybride est très majoritairement implantée dans les véhicules volumineux (4x4 et SUV), qui sont par nature les véhicules les plus chers du marché. À l'inverse, nos modèles 100% électriques se concentrent davantage sur le segment des citadines, ce qui tire naturellement leur prix médian vers le bas."

    # TEXTE 3 : La décote kilométrique (Idée 2)
    texte_decote <- "
      <ul style='font-size: 15px; line-height: 1.6; margin-bottom: 0;'>
        <li><strong>La résilience de l'Hybride :</strong> Partant d'un prix d'achat initial très haut, l'hybride maintient sa valeur au fil des kilomètres. Les clients occasion sont rassurés par la fiabilité perçue et l'absence de contraintes de recharge.</li>
        <li><strong>La crainte de la batterie sur l'Électrique :</strong> La pente de décote de l'électrique est soumise à la défiance des acheteurs face au vieillissement des batteries. Passé un certain cap kilométrique, la valeur chute plus durement que le thermique.</li>
        <li><strong>Le Thermique, valeur refuge :</strong> Sa courbe de décote reste la plus prévisible et constitue le référentiel du marché.</li>
      </ul>"

    # Affichage stylisé final (Assemblage des 3 parties avec des séparateurs visuels)
    tags$div(
      class = "alert alert-primary", style = "background-color: #e6f2f8; border-color: #003c58; color: #003c58;",

      # Point 1
      tags$h5(tags$b("1. Les prix selon le type de motorisation")),
      HTML(texte_prix),

      # Séparateur
      tags$hr(style = "border-top: 1px solid #003c58; opacity: 0.3; margin-top: 15px; margin-bottom: 15px;"),

      # Point 2
      tags$h5(tags$b("2. L'effet de gamme (Pourquoi l'hybride est-il si cher ?)")),
      HTML(texte_categorie),

      # Séparateur
      tags$hr(style = "border-top: 1px solid #003c58; opacity: 0.3; margin-top: 15px; margin-bottom: 15px;"),

      # Point 3
      tags$h5(tags$b("3. La résistance à l'usure (Impact du kilométrage)")),
      HTML(texte_decote)
    )
  })
  # =========================================================================
  # IDÉE 1 : Répartition des Énergies par Catégorie (Stacked Bar)
  # =========================================================================
  output$h4_stacked_cat <- renderPlotly({
    # 1. Préparation des données
    d_cat <- df_energie() %>%
      filter(!is.na(category), category != "") %>%
      count(category, Type_Motorisation) %>%
      group_by(category) %>%
      mutate(
        proportion = n / sum(n),
        total_cat = sum(n),
        # Info-bulle personnalisée
        custom_tooltip = paste0(
          "Catégorie : ", category, "\n",
          "Motorisation : ", Type_Motorisation, "\n",
          "Volume : ", n, " ventes\n",
          "Proportion : ", round(proportion * 100, 1), " %"
        )
      ) %>%
      ungroup()

    # 2. Création du graphique
    p_cat <- ggplot(d_cat, aes(y = reorder(category, total_cat), x = proportion, fill = Type_Motorisation, text = custom_tooltip)) +
      geom_col(position = "stack", alpha = 0.9) +
      scale_fill_manual(values = c(
        "Thermique" = "#bdc3c7",
        "Hybride" = "#003c58",
        "Électrique" = "#69d625"
      )) +
      scale_x_continuous(labels = scales::percent) +
      labs(y = "", x = "Proportion des ventes") +
      theme_minimal() +
      theme(legend.title = element_blank())

    # 3. Affichage
    suppressWarnings(ggplotly(p_cat, tooltip = "text"))
  })

  # =========================================================================
  # IDÉE 2 : Décote du prix selon le kilométrage (Scatter plot + Tendance)
  # =========================================================================
  output$h4_scatter_km <- renderPlotly({
    
    # Préparation et filtrage des données
    d_km <- df_energie() %>%
      filter(mileage < 150000, price < 60000) %>%
      # Création d'un texte personnalisé pour chaque point
      mutate(label_tooltip = paste0(
        "<b>Modèle : </b>", Type_Motorisation, "<br>",
        "<b>Prix : </b>", format(price, big.mark = " "), " €<br>",
        "<b>Kilométrage : </b>", format(mileage, big.mark = " "), " km"
      ))
    
    # Création du graphique
    p_km <- ggplot(d_km, aes(
      x = mileage,
      y = price,
      color = Type_Motorisation
    )) + 
      geom_point(aes(text = label_tooltip), alpha = 0.3, size = 1) +
      geom_smooth(method = "gam", se = FALSE, linewidth = 1.2) +
      scale_color_manual(values = c(
        "Thermique" = "#bdc3c7",
        "Hybride" = "#003c58",
        "Électrique" = "#69d625"
      )) +
      labs(x = "Kilométrage", y = "Prix TTC (€)") +
      theme_minimal() +
      theme(legend.title = element_blank())
    
    # Conversion Plotly
    suppressWarnings(
      ggplotly(p_km, tooltip = "text") %>%
        layout(hovermode = "closest")
    )
  })


  # ----------------------------------------------------------------------------
  # PAGE 4 : VALEUR DES ÉQUIPEMENTS
  # ----------------------------------------------------------------------------
  df_h6 <- reactive({
    req(input$h6_category)
    data <- if (input$h6_category != "Toutes") {
      df() %>% filter(category == input$h6_category)
    } else {
      df()
    }
    # On s'assure qu'on a assez de données pour une régression (> 10 obs)
    req(nrow(data) > 10)
    data
  })

  modele_eq_reactive <- reactive({
    eq_cols <- grep("^eq_", names(df_h6()), value = TRUE)

    # Filtrage analytique pour la régression
    if (input$h6_category == "Toutes") {
      formule <- as.formula(paste("price ~ mileage + buyer_age + category +", paste(eq_cols, collapse = " + ")))
    } else {
      formule <- as.formula(paste("price ~ mileage + buyer_age +", paste(eq_cols, collapse = " + ")))
    }

    lm(formule, data = df_h6())
  })

  df_coefs_reactive <- reactive({
    modele_eq <- modele_eq_reactive()
    coefs <- summary(modele_eq)$coefficients

    d_c <- data.frame(
      Equipment = rownames(coefs),
      Estimate = coefs[, "Estimate"],
      Pval = coefs[, "Pr(>|t|)"]
    ) %>%
      filter(grepl("^eq_", Equipment)) %>%
      mutate(Equipment = gsub("^eq_", "", Equipment)) %>%
      mutate(Equipment = gsub("_", " ", Equipment)) %>%
      arrange(desc(Estimate))

    d_c$Significatif <- ifelse(d_c$Pval < 0.05, "Oui (Fiable)", "Non (Incertain)")
    d_c
  })

  output$h6_bar_coefs <- renderPlotly({
    
    # 1. Préparation des données et création de l'info-bulle sur mesure
    d_c <- df_coefs_reactive() %>%
      mutate(
        # On arrondit l'estimation et on ajoute un "+" si c'est positif
        signe = ifelse(Estimate > 0, "+ ", ""),
        valeur_formatee = format(round(Estimate, 0), big.mark = " "),
        
        # Création du texte HTML pour l'info-bulle
        custom_tooltip = paste0(
          "<b>Équipement : </b>", Equipment, "<br>",
          "<b>Impact estimé : </b>", signe, valeur_formatee, " €<br>",
          "<b>Fiabilité : </b>", Significatif
        )
      )
    
    # 2. Création du graphique (Axes X et Y inversés nativement, plus de coord_flip)
    p <- ggplot(d_c, aes(
      y = reorder(Equipment, Estimate), 
      x = Estimate, 
      fill = Significatif,
      text = custom_tooltip # On injecte l'info-bulle ici
    )) +
      geom_col() +
      scale_fill_manual(values = c("Oui (Fiable)" = secondary_color, "Non (Incertain)" = "#95a5a6")) +
      labs(y = "", x = "Plus-value estimée (€) sur le prix de vente") +
      theme_minimal() +
      theme(
        legend.position = "bottom",
        legend.title = element_blank() # Enlève le titre "Significatif" au-dessus de la légende
      )
    
    # 3. Conversion Plotly
    suppressWarnings(
      ggplotly(p, tooltip = "text") %>%
        # layout(hovermode = "y unified") # Optionnel : affiche une belle ligne horizontale au survol
        layout(hovermode = "closest")
    )
  })

  output$h6_table_coefs <- DT::renderDataTable({
    d_show <- df_coefs_reactive() %>%
      select(`Option` = Equipment, `Plus-value (€)` = Estimate, `Fiabilité` = Significatif) %>%
      mutate(`Plus-value (€)` = round(`Plus-value (€)`, 0))
    datatable(d_show, options = list(dom = "t", pageLength = 15, scrollY = "300px"), rownames = FALSE)
  })

  output$h6_raw_summary <- renderPrint({
    summary(modele_eq_reactive())
  })

  output$h6_raw_explanation <- renderUI({
    texte <- "La sortie brute de R (ci-dessus) présente les statistiques complètes de la régression linéaire multiple. La colonne <b>Estimate</b> montre l'impact financier de chaque variable sur le prix de revente final. La dernière colonne (les fameuses étoiles `***`) indique la robustesse mathématique de ce calcul (p-value). Plus il y a d'étoiles, plus on est certain que cet équipement augmente bien le prix et que ce n'est pas un coup de chance de la base de données."
    tags$div(
      class = "well text-muted",
      tags$b("Comment lire cette sortie ? "), HTML(texte)
    )
  })

  # ----------------------------------------------------------------------------
  # PAGE 5 : ACP Équipements
  # ----------------------------------------------------------------------------
  df_h5 <- reactive({
    data <- df()
    if (!is.null(input$h5_category) && input$h5_category != "Toutes") {
      data <- data %>% filter(category == input$h5_category)
    }
    
    # Toutes les variables numériques pertinentes
    eq_cols <- grep("^eq_", names(data), value = TRUE)
    num_cols <- c("price", "mileage", "buyer_age", "agency_dist", "nb_equipments", eq_cols)
    
    d_agg <- data %>%
      mutate(
        is_Thermique = as.numeric(grepl("essence|diesel", tolower(engine_type))),
        is_Hybride = as.numeric(grepl("hybride", tolower(engine_type))),
        is_Electrique = as.numeric(grepl("electrique|électrique", tolower(engine_type)))
      ) %>%
      group_by(model) %>%
      summarise(
        volume = n(),
        across(all_of(num_cols), ~ mean(.x, na.rm = TRUE)),
        prop_Thermique = mean(is_Thermique, na.rm = TRUE),
        prop_Hybride = mean(is_Hybride, na.rm = TRUE),
        prop_Electrique = mean(is_Electrique, na.rm = TRUE)
      ) %>%
      filter(volume >= 5) # Filtrer les modèles rares
    
    req(nrow(d_agg) > 3) # Il faut un minimum de modèles pour faire une ACP
    d_agg
  })
  
  pca_obj <- reactive({
    d_agg <- df_h5()
    eq_cols <- grep("^eq_", names(d_agg), value = TRUE)
    num_cols <- c("price", "mileage", "buyer_age", "agency_dist", "nb_equipments", eq_cols, "prop_Thermique", "prop_Hybride", "prop_Electrique")
    
    # On évite des colonnes non trouvées (sécurité additionnelle)
    num_cols <- intersect(num_cols, names(d_agg))
    
    # On retire les colonnes qui auraient une variance nulle
    valid_cols <- sapply(num_cols, function(col) var(d_agg[[col]], na.rm = TRUE) > 0)
    final_cols <- num_cols[valid_cols]
    
    req(length(final_cols) > 2)
    
    # Exécution de l'ACP globale avec FactoMineR
    res.pca <- PCA(as.data.frame(d_agg)[, final_cols], scale.unit = TRUE, ncp = 5, graph = FALSE)
    list(pca = res.pca, data = d_agg)
  })
  
  output$h5_pc3_ui <- renderUI({
    req(pca_obj())
    res.pca <- pca_obj()$pca
    if (nrow(res.pca$eig) >= 3) {
      var_pc3 <- round(res.pca$eig[3, 2], 1)
      if (var_pc3 >= 8) { # Seuil minimum explicatif
        checkboxInput("h5_show_pc3", paste0("Basculer sur l'Axe 3 (", var_pc3, "%)"), value = FALSE)
      } else {
        p(class = "text-muted small", paste0("Axe 3 masqué (non significatif : ", var_pc3, "%)"))
      }
    }
  })

  output$h5_acp_plot <- renderPlotly({
    req(pca_obj())
    res.pca <- pca_obj()$pca
    d_agg <- pca_obj()$data
    
    # Extraction de la variance expliquée par dimension (FactoMineR)
    var_exp <- round(res.pca$eig[, 2], 1)
    
    # Extraction des coordonnées des individus (Modèles)
    scores <- as.data.frame(res.pca$ind$coord)
    colnames(scores)[1:ncol(scores)] <- paste0("PC", 1:ncol(scores))
    scores$model <- d_agg$model
    scores$price <- d_agg$price
    scores$volume <- d_agg$volume
    
    # Extraction des coordonnées des variables (Equipements et Autres)
    loadings <- as.data.frame(res.pca$var$coord)
    colnames(loadings)[1:ncol(loadings)] <- paste0("PC", 1:ncol(loadings))
    loadings$var <- rownames(loadings)
    # Renommer proprement
    loadings$var <- gsub("^eq_", "", loadings$var)
    loadings$var <- gsub("^prop_", "Moteur ", loadings$var)
    loadings$var <- gsub("_", " ", loadings$var)
    loadings$var[loadings$var == "price"] <- "Prix"
    loadings$var[loadings$var == "mileage"] <- "Kilométrage"
    loadings$var[loadings$var == "buyer age"] <- "Âge Acheteur"
    loadings$var[loadings$var == "agency dist"] <- "Distance Agence"
    loadings$var[loadings$var == "nb equipments"] <- "Nb Options"
    
    show_pc3 <- isTruthy(input$h5_show_pc3) && ncol(scores) >= 3
    y_dim <- if (show_pc3) "PC3" else "PC2"
    y_var <- if (show_pc3) var_exp[3] else var_exp[2]

    # Constante de mise à l'échelle pour superposer les flèches et les points esthétiquement
    scale_factor <- max(abs(scores$PC1)) / max(abs(loadings$PC1)) * 0.8
    
    p <- ggplot() +
      # Points (Modèles)
      geom_point(data = scores,
                 aes(x = PC1, y = .data[[y_dim]], color = price, size = volume,
                     text = paste0("<b>Modèle : </b>", model, 
                                   "<br><b>Prix moyen : </b>", format(round(price, 0), big.mark = " ", scientific=FALSE), " €",
                                   "<br><b>Volume : </b>", volume)),
                 alpha = 0.8) +
      scale_color_gradient(low = "#18bc9c", high = "#e74c3c", name = "Prix Moyen (€)") +
      scale_size_continuous(range = c(2, 6), guide = "none") +
      
      # Flèches (Loadings)
      geom_segment(data = loadings,
                   aes(x = 0, y = 0, xend = PC1 * scale_factor, yend = .data[[y_dim]] * scale_factor),
                   arrow = arrow(length = unit(0.2, "cm")), color = "#2c3e50", alpha = 0.6) +
      # Noms des équipements
      geom_text(data = loadings,
                aes(x = PC1 * scale_factor * 1.1, y = .data[[y_dim]] * scale_factor * 1.1, label = var),
                color = "#2c3e50", size = 3, check_overlap = TRUE) +
      
      labs(x = paste0("PC1 (", var_exp[1], "%)"),
           y = paste0(if (show_pc3) "PC3" else "PC2", " (", y_var, "%)")) +
      theme_minimal() +
      geom_hline(yintercept = 0, linetype = "dashed", color = "gray") +
      geom_vline(xintercept = 0, linetype = "dashed", color = "gray")
    
    ggplotly(p, tooltip = "text") %>%
      layout(hovermode = "closest")
  })
}
