library(shiny)
library(bslib)
library(bsicons)
library(dplyr)
library(ggplot2)
library(DT)
library(plotly)
library(FactoMineR)

video_tuto_panel <- function(start_time) {
  accordion(
    open = FALSE,
    class = "video-accordion",
    accordion_panel(
      title = "▶️ Tutoriel Vidéo",
      icon = bsicons::bs_icon("play-circle"),
      tags$div(
        style = "text-align: center;",
        tags$iframe(
          width = "560", 
          height = "315", 
          src = paste0("https://www.youtube.com/embed/4Q-OoNSKUWk?start=", start_time), 
          title = "YouTube video player", 
          frameborder = "0", 
          allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen", 
          allowfullscreen = "allowfullscreen"
        )
      ),
      p(class = "text-muted small text-center mt-2", "Cliquez sur play pour lancer la vidéo tutorielle de cet onglet.")
    )
  )
}

ui <- page_navbar(
  title = tags$div(
    tags$img(src = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtzNfYqOjK96bEUSGu14twQWzsvmSplFOSFQ&s", height = "50px", style = "margin-right: 15px;"),
    "Dashboard AramisAuto"
  ),
  bg = "#003c58", 
  theme = bs_theme(
    version = 5, 
    bootswatch = "yeti", 

    primary = "#003c58",
    secondary = "#69d625"
  
  ),
  header = tags$head( 
    tags$style(HTML("
      .accordion-button { 
        background-color: #003c58 !important; 
        color: white !important; 
        font-weight: bold;
        border-radius: 8px !important;
      }
      .accordion-button:not(.collapsed) { 
        background-color: #1a252f !important; 
        box-shadow: none !important;
      }
      .accordion-button::after { 
        filter: brightness(0) invert(1); 
      }
      .accordion-item {
        border: none !important;
        margin-bottom: 10px;
      }
      
      .video-accordion .accordion-button {
        background-color: #dc3545 !important;
      }
      .video-accordion .accordion-button:not(.collapsed) {
        background-color: #c82333 !important;
      }
      
      /* Correction des filtres DT (DataTables) pour éviter overlaps ou coupures */
      .irs, .selectize-dropdown {
        z-index: 9999 !important;
      }
      th {
        white-space: nowrap !important;
      }
    "))
  ),

  # ----------------------------------------------------------------------------
  # PAGE 1 : Présentation générale & Stats globales
  # ----------------------------------------------------------------------------
  nav_panel("1. Synthèse",
    fluidRow(
      column(12,
        h2("Analyse des ventes automobiles - AramisAuto"),
        p("Ce tableau de bord interactif permet d'analyser les données de vente de véhicules d'AramisAuto. 
          Il a pour but de fournir des indicateurs clairs et compréhensibles par tous, afin d'aider à la 
          prise de décision et d'optimiser la gestion du stock."),
        video_tuto_panel(0)
      )
    ),
    hr(),
    # KPI interactifs sous forme d'accordéons pour permettre le "clic pour détails"
    fluidRow(
      layout_column_wrap(
        width = 1, # Un seul pannel par ligne pour une visibilité maximale
        # Un seul accordéon avec multiple = FALSE pour garantir l'exclusivité (un pannel ouvert à la fois)
        accordion(
          id = "acc_kpis",
          multiple = FALSE,
          open = FALSE,
          
          # KPI 1: Total
          accordion_panel(
            title = "Total Véhicules",
            value = "kpi_total_panel",
            icon = bsicons::bs_icon("car-front"),
            list(tags$b("Total : "), textOutput("kpi_total", inline = TRUE)),
            plotlyOutput("plot_detail_total", height = "300px"),
            p(class = "text-muted small", "Répartition volumétrique du stock actuel.")
          ),
          
          # KPI 2: Prix
          accordion_panel(
            title = "Prix Moyen",
            value = "kpi_prix_panel",
            icon = bsicons::bs_icon("currency-euro"),
            list(tags$b("Moyenne : "), textOutput("kpi_prix", inline = TRUE)),
            plotlyOutput("plot_detail_prix", height = "300px"),
            p(class = "text-muted small", "Distribution des prix de vente (TTC).")
          ),
          
          # KPI 3: Kilométrage
          accordion_panel(
            title = "Km Moyen",
            value = "kpi_km_panel",
            icon = bsicons::bs_icon("speedometer2"),
            list(tags$b("Moyenne : "), textOutput("kpi_km", inline = TRUE)),
            plotlyOutput("plot_detail_km", height = "300px"),
            p(class = "text-muted small", "Répartition de l'usure du parc.")
          ),
          
          # KPI 4: Âge
          accordion_panel(
            title = "Âge Moyen",
            value = "kpi_age_panel",
            icon = bsicons::bs_icon("person"),
            list(tags$b("Moyenne : "), textOutput("kpi_age", inline = TRUE)),
            plotlyOutput("plot_detail_age", height = "300px"),
            p(class = "text-muted small", "Profil démographique de nos acheteurs.")
          ),
          
          # KPI 5: Distance
          accordion_panel(
            title = "Dist. Moyen",
            value = "kpi_dist_panel",
            icon = bsicons::bs_icon("geo-alt"),
            list(tags$b("Moyenne : "), textOutput("kpi_distance", inline = TRUE)),
            plotlyOutput("plot_detail_distance", height = "300px"),
            p(class = "text-muted small", "Éloignement moyen du client par rapport à l'agence.")
          )
        )
      )
    ),
    br(),
    # Graphiques d'exploration
    fluidRow(
      column(6, 
        card(
          card_header("Où se situent nos prix ?"),
          plotlyOutput("hist_price"),
          br(),
          p(class = "text-muted mb-0", "Ce graphique montre comment se répartissent les prix de nos véhicules. On peut y voir quelle tranche de prix est la plus fréquente dans notre stock.")
        )
      ),
      column(6, 
        card(
          card_header("Quel est l'usage de nos véhicules ?"),
          plotlyOutput("hist_km"),
          br(),
          p(class = "text-muted mb-0", "Ici, on observe la répartition des kilométrages. Cela permet de savoir si nous vendons majoritairement des véhicules récents ou plus anciens.")
        )
      )
    ),
    br(),
    fluidRow(
      column(6, 
        card(
          card_header("Combien de temps pour vendre ?"),
          plotlyOutput("hist_delai"),
          br(),
          p(class = "text-muted mb-0", "Ce graphique illustre le délai de vente (en jours). Une forte concentration à gauche indique que la majorité des voitures se vendent rapidement.")
        )
      ),
      column(6, 
        card(
          card_header("Quelles marques vendons-nous le plus ?"),
          plotlyOutput("bar_brand"),
          br(),
          p(class = "text-muted mb-0", "Ce classement affiche le volume de véhicules disponibles par marque, mettant en évidence nos principaux fournisseurs ou choix de stock.")
        )
      )
    ),
    hr(),
    accordion(
      open = FALSE,
      accordion_panel(
        title = "Données détaillées (Base de données brute)",
        icon = bsicons::bs_icon("table"),
        p(class = "text-muted", "Utilisez ce tableau interactif pour trier, filtrer par colonne, ou chercher une caractéristique spécifique. Vous pouvez aussi ajuster le nombre de lignes affichées (ex: voir les 50 premières lignes)."),
        div(style = "overflow-x: auto; overflow-y: visible; padding-bottom: 40px;", 
            DT::dataTableOutput("table_global")
        )
      )
    )
  ),

  # ----------------------------------------------------------------------------
  # PAGE 2 : Profil Acheteur
  # ----------------------------------------------------------------------------
  nav_panel("2. Profil Acheteur",
    fluidRow(
      column(12,
        h3("L'âge de l'acheteur influence-t-il la marque, le budget ou le type de véhicule ?"),
        p("Connaître le persona de nos acheteurs est essentiel pour cibler nos campagnes marketing. Analysez ici le comportement de notre clientèle en fonction de son âge."),
        video_tuto_panel(40),
        hr()
      )
    ),
    fluidRow(
      column(3, 
        card(
          height = "100%",
          card_header(tags$b(bsicons::bs_icon("funnel"), " Filtres d'Analyse")),
          selectInput("h2_category", "Catégorie de véhicule :", choices = c("Toutes", "4x4 et SUV", "Autre", "Berline Compacte", "Break", "Citadine", "Monospace")),
          selectInput("h2_engine", "Motorisation :", choices = c("Toutes", "Thermique", "Hybride", "Électrique")),
          p(class = "text-muted small", "Utilisez ces filtres pour affiner le profil de la clientèle selon les spécificités d'un segment du parc auto.")
        )
      ),
      column(9,
        fluidRow(
          column(6, 
            card(
               plotlyOutput("h2_boxplot"),
               p(class = "text-muted mb-0 mt-2", "Âge moyen des acheteurs (Top 6 des marques du segment)."),
               div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
                   tags$em(class = "text-muted small", "💡 Ce graphique permet d'identifier si certaines marques séduisent une clientèle historiquement plus âgée (souvent lié au pouvoir d'achat) ou plus jeune.")
               )
            )
          ),
          column(6, 
            card(
              plotlyOutput("h2_scatter"),
              p(class = "text-muted mb-0 mt-2", "Relation entre l'âge de l'acheteur et le prix du véhicule acheté."),
              div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
                  tags$em(class = "text-muted small", "💡 Observez ici la corrélation directe entre le budget investi et l'âge du client. La courbe de tendance met en évidence la trajectoire d'achat au cours d'une vie.")
              )
            )
          )
        ),
        br(),
        fluidRow(
          column(12,
            card(
              plotlyOutput("h2_bar_age", height = "350px"),
              p(class = "text-muted mb-0 mt-2", "Répartition des ventes par catégorie de carrosserie selon la tranche d'âge."),
              div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
                  tags$em(class = "text-muted small", "💡 L'évolution du cycle de vie est claire : les jeunes acheteurs dominent souvent sur les citadines, puis le besoin d'espace (milieu de vie) pousse vers les SUV ou Monospaces. Les seniors retrouvent parfois des véhicules plus compacts mais très équipés.")
              )
            )
          )
        )
      )
    ),
    br(),
    fluidRow(
      column(12,
        uiOutput("h2_interpretation")
      )
    )
  ),

  # ----------------------------------------------------------------------------
  # PAGE 3 : Type & Énergie
  # ----------------------------------------------------------------------------
  nav_panel("3. Type & Énergie",
    fluidRow(
      column(12,
        h3("Hybride/Électrique vs Thermique : Les clients payent-ils vraiment plus cher, comment expliquer ces écarts ?"),
        p("Avec la transition énergétique, les prix des véhicules 'propres' s'envolent. Observons cela sur nos données."),
        video_tuto_panel(127),
        hr()
      )
    ),
    fluidRow(
      column(6, 
        card(
           plotlyOutput("h4_boxplot"),
           p(class = "text-muted mb-0", "Répartition des prix (TTC) payés par les clients, catégorisés par type d'énergie (Thermique, Hybride, Électrique)."),
           div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
               tags$em(class = "text-muted small", "💡 Contre toute attente, la modalité la plus chère n'est pas le 100% électrique, mais l'Hybride, qui affiche les prix les plus élevés. Les véhicules électriques, quant à eux, conservent un positionnement tarifaire étonnamment proche des modèles thermiques classiques")
           )
        )
      ),
      column(6, 
        card(
          plotlyOutput("h4_bar"),
          p(class = "text-muted mb-0", "Nombre de véhicules vendus par type d'énergie (Volume de vente global)."),
          div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
              tags$em(class = "text-muted small", "💡 Le nombre de véhicules thermiques est nettement majoritaire (n = 3166), tandis que les volumes en électrique sont plus restreints (n = 167), un élément à nuancer pour dans nos analyses.")
          )
        )
      )
    ),
    br(),
    fluidRow(
      column(6, 
             card(
               plotlyOutput("h4_stacked_cat"),
               p(class = "text-muted mb-0", "Répartition des parts de ventes de chaque catégorie de voitures par type de moteur"),
               div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
                   tags$em(class = "text-muted small", "💡 L'analyse des prix révèle une élément : la technologie hybride tire les tarifs à la hausse, s'imposant comme la motorisation la plus chère. À l'inverse, le ticket d'entrée pour un véhicule 100% électrique reste compétitif. Cette proximité tarifaire avec le thermique s'explique par la forte présence de petites citadines électriques dans le stock actuel, face à des modèles hybrides souvent positionnés dans la catégorie SUV.")
               )
             )
      ),
      column(6, 
             card(
               plotlyOutput("h4_scatter_km"),
               p(class = "text-muted mb-0", "Évolution du prix de vente en fonction du kilométrage selon le type de moteur."),
               div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
                   tags$em(class = "text-muted small", "💡 Le prix des véhicules hybrides diminue aussi progressivement que les thermiques, tout en conservant une valeur supérieure. La décote des véhicules électriques est quant à elle légèrement plus accentuée.")
               )
             ),
             
      )
    ),
    
    fluidRow(
      column(12,
        uiOutput("h4_interpretation")
      )
    )
  ),

  # ----------------------------------------------------------------------------
  # PAGE 4 : Valeur des Équipements
  # ----------------------------------------------------------------------------
  nav_panel("4. Valeur des Équipements",
    fluidRow(
      column(12,
        h3("Quels équipements font vraiment grimper le prix ?"),
        p("Modélisation de l'impact financier de chaque équipement (ex: Caméra de recul, Toit ouvrant) sur le prix de vente TTC à véhicule équivalent."),
        video_tuto_panel(277),
        hr()
      )
    ),
    fluidRow(
      column(2, 
        card(
          height = "450px",
          card_header("Configuration"),
          selectInput("h6_category", "Catégorie ciblée :", choices = c("Toutes", "4x4 et SUV", "Autre", "Berline Compacte", "Break", "Citadine", "Monospace")),
          p(class = "text-muted small", "Filtrez par type de véhicule.")
        )
      ),
      column(7,
        card(
          card_header("Impact des équipements sur le prix"),
          plotlyOutput("h6_bar_coefs", height = "450px"),
          p(class = "text-muted small mb-0", 
            "Barres vertes : impact fiable. Barres grises : impact incertain.")
        )
      ),
      column(3,
        card(
          height = "450px",
          card_header("Détails financiers"),
          DT::dataTableOutput("h6_table_coefs")
        )
      )
    ),
    hr(),
    fluidRow(
      column(12,
        accordion(
          open = FALSE,
          accordion_panel(
            "Sortie statistique brute du modèle complet",
            verbatimTextOutput("h6_raw_summary"),
            br(),
            uiOutput("h6_raw_explanation")
          )
        )
      )
    )
  ),

  # ----------------------------------------------------------------------------
  # PAGE 5 : ACP Équipements
  # ----------------------------------------------------------------------------
  nav_panel("5. Modèles (ACP Globale)",
    fluidRow(
      column(12,
        h3("Analyse Multidimensionnelle de la Gamme (Prix, Usure, Équipements)"),
        p("L'Analyse en Composantes Principales (ACP) croise l'ensemble des variables (prix, kilométrage, âge de l'acheteur, équipements) pour faire ressortir les grandes liaisons entre elles."),
        video_tuto_panel(345),
        hr()
      )
    ),
    fluidRow(
      column(3, 
             card(
               height = "100%",
               card_header(tags$b(bsicons::bs_icon("funnel"), " Filtres d'Analyse")),
               selectInput("h5_category", "Catégorie ciblée :", choices = c("Toutes", "4x4 et SUV", "Berline Compacte", "Citadine", "Autre", "Break", "Monospace")),
               hr(),
               uiOutput("h5_pc3_ui"),
               p(class = "text-muted small", "Filtrez pour lire le graphique d'une catégorie spécifique. L'ACP est recalculée dynamiquement pour les modèles concernés.")
             )
      ),
      column(9,
             card(
               card_header("Analyse en Composante Principale (Équipements, Prix, Kilométrage...)"),
               plotlyOutput("h5_acp_plot", height = "500px"),
               div(class = "mt-3 p-3 rounded", style = "background-color: #f8f9fa; border: 1px dashed #adb5bd;",
                   HTML("<span class='text-muted small'>💡 <b>Mini-Tuto : Comment lire cette carte (ACP) ?</b><br>
                        • <b>Les bulles (Modèles) :</b> Deux bulles physiquement proches sur le graphique désignent des voitures ayant des caractéristiques (options, âge, usure) presque identiques.<br>
                        • <b>Lien flèches/bulles :</b> Si une bulle se trouve dans la direction d'une flèche, c'est qu'elle possède un score très élevé pour cette caracteristique.<br>
                        • <b>L'angle entre les flèches :</b> Des flèches qui pointent dans le même sens forment un groupe d'options qui vont systématiquement de pair. À l'inverse, si deux flèches partent dans des directions opposées, cela signifie que ces deux caractéristiques se rencontrent très rarement ensemble sur une même voiture.</span>")
               )
             )
      )
    ),
    br()
  )
)
